package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bank.entity.Admin;
import com.bank.entity.Customer;
import com.bank.service.BankService;
import com.bank.service.IBankService;


@Controller
public class BankController {

@Autowired
private IBankService bankService;
@RequestMapping("/index")
public String dummy(Model model){
	
	return "index";
}
	
@RequestMapping("/adminlogin")
public String dummy1(Model model){
	model.addAttribute("login",new Admin());
	return "adminlogin";
}


@RequestMapping("/adminsuccess")
 	public String adminLogin(@RequestParam("adminid") int adminId,
 			@RequestParam("password") String password,@ModelAttribute("login") Admin admin ,Model model) 
	{
	int adminId1=bankService.login(adminId, password);
	if(adminId1==0)
	{
		model.addAttribute("message","wrong credentials.......try again");
		return "adminlogin";
	}
	else
	{
		model.addAttribute("message","login successful");
		return "adminsuccess";
	}	
		
	}

@RequestMapping("/createaccount")
public String save(Model model){
	model.addAttribute("accountType",new String[]{"savingsaccount","currentaccount"});
	model.addAttribute("createaccounts",new Customer());
	return "createaccount";
}
@RequestMapping(value="/createaccount2")
public String createAccount(@ModelAttribute("createaccounts")Customer customer, Model model){
	//model.addAttribute("createaccount",new Customer());
	//model.addAttribute("accountType",new String[]{"savingsaccount","currentaccount"});
	//model.addAttribute(bankService.add(customer));
	customer =  bankService.add(customer);
	return "createaccount1";
	
}

}

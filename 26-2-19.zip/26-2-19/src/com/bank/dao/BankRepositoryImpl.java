package com.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.bank.entity.Customer;

@Repository
public class BankRepositoryImpl implements IBankRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int login(int adminId,String password)
	{
		TypedQuery<Integer> query=entityManager.createQuery("SELECT a.adminid FROM Admin a where a.adminid=:padminId and a.password=:ppassword",Integer.class);
		query.setParameter("padminId", adminId);
		query.setParameter("ppassword", password);
		int adminId1=query.getSingleResult();
		if(adminId1==0){
			int loggeduser=0;
			return loggeduser;
		}
		else{
			int loggeduser=adminId1;
			return loggeduser;	
	}
	}

	@Override
	public Customer add(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}

}

package com.bank.dao;

import com.bank.entity.Customer;

public interface IBankRepository {

	int login(int adminId, String password);
	Customer add(Customer customer);
}

package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.dao.IBankRepository;
import com.bank.entity.Customer;

@Transactional
@Service
public class BankService implements IBankService{
	@Autowired
	private IBankRepository bankrepository;

	@Override
	public int login(int adminId, String password) {
		
		return bankrepository.login(adminId, password);
	}

	@Override
	public Customer add(Customer customer) {
		
		return bankrepository.add(customer);
	}

	
	

}

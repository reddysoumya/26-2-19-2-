package com.bank.service;

import com.bank.entity.Customer;

public interface IBankService {
	int login(int adminId, String password);

	Customer add(Customer customer);

	

}

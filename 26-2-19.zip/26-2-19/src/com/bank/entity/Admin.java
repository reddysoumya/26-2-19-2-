package com.bank.entity;

//****************Importing Required Packages********************************//
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

//*******************************ADMIN ENTITY CLASS****************************//
@Entity
public class Admin {
	
	
	@Id           //AdminId as a Primary Key
	@Column       //adminId as a column name
	private int adminid;
	@Column       //password as a column name
	private String password;
	
//*****************Generating getters and setters*****************************//
	public int getAdminid() {
		return adminid;
	}
	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}
	
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

}

package com.bank.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="payee_table")
public class Payee {
	
	@Id
	private int accountId;
	private int payeeAccId;
	private String nickName;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(int payeeAccId) {
		this.payeeAccId = payeeAccId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	
	
}
